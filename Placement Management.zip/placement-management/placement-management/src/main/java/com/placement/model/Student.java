package com.placement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {

    @Id
    private Long id;
    private String name;
    private String qualification;
    private String course;
    private int year;
    private Long hallTicketNo;

    public Student() {
    }

    public Student(Long id, String name, String qualification, String course, int year, Long hallTicketNo) {
        this.id = id;
        this.name = name;
        this.qualification = qualification;
        this.course = course;
        this.year = year;
        this.hallTicketNo = hallTicketNo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Long getHallTicketNo() {
        return hallTicketNo;
    }

    public void setHallTicketNo(Long hallTicketNo) {
        this.hallTicketNo = hallTicketNo;
    }
}