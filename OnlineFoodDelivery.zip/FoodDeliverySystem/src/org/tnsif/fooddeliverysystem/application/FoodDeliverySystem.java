package org.tnsif.fooddeliverysystem.application;

import java.util.Scanner;

public class FoodDeliverySystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;

        do {

            System.out.println("\n1. Admin Menu");
            System.out.println("2. Customer Menu");
            System.out.println("3. Exit");

            System.out.print("Choose an option: ");
            choice = sc.nextInt();

            switch(choice) {

                case 1:
                    adminMenu(sc);
                    break;

                case 2:
                    customerMenu(sc);
                    break;

                case 3:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice");

            }

        } while(choice != 3);

        sc.close();
    }

    // Admin Menu
    public static void adminMenu(Scanner sc) {

        int adminChoice;

        do {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Add Food Item to Restaurant");
            System.out.println("3. Remove Food Item from Restaurant");
            System.out.println("4. View Restaurants and Menus");
            System.out.println("5. View Orders");
            System.out.println("6. Add Delivery Person");
            System.out.println("7. Assign Delivery Person to Order");
            System.out.println("8. Exit");

            System.out.print("Choose an option: ");
            adminChoice = sc.nextInt();

            switch(adminChoice) {

                case 1:
                    System.out.println("Add Restaurant selected");
                    break;

                case 2:
                    System.out.println("Add Food Item selected");
                    break;

                case 3:
                    System.out.println("Remove Food Item selected");
                    break;

                case 4:
                    System.out.println("View Restaurants selected");
                    break;

                case 5:
                    System.out.println("View Orders selected");
                    break;

                case 6:
                    System.out.println("Add Delivery Person selected");
                    break;

                case 7:
                    System.out.println("Assign Delivery Person selected");
                    break;

                case 8:
                    System.out.println("Exiting Admin Module");
                    break;

                default:
                    System.out.println("Invalid choice");

            }

        } while(adminChoice != 8);
    }

    // Customer Menu
    public static void customerMenu(Scanner sc) {

        int customerChoice;

        do {
            System.out.println("\nCustomer Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. View Food Items");
            System.out.println("3. Add Food to Cart");
            System.out.println("4. View Cart");
            System.out.println("5. Place Order");
            System.out.println("6. View Orders");
            System.out.println("7. Exit");

            System.out.print("Choose an option: ");
            customerChoice = sc.nextInt();

            switch(customerChoice) {

                case 1:
                    System.out.println("Add Customer selected");
                    break;

                case 2:
                    System.out.println("View Food Items selected");
                    break;

                case 3:
                    System.out.println("Add Food to Cart selected");
                    break;

                case 4:
                    System.out.println("View Cart selected");
                    break;

                case 5:
                    System.out.println("Place Order selected");
                    break;

                case 6:
                    System.out.println("View Orders selected");
                    break;

                case 7:
                    System.out.println("Exiting Customer Module");
                    break;

                default:
                    System.out.println("Invalid choice");

            }

        } while(customerChoice != 7);
    }
}