package org.tnsif.fooddeliverysystem.services;

import java.util.ArrayList;
import java.util.List;

import org.tnsif.fooddeliverysystem.entities.Customer;

public class CustomerService {


	    private List<Customer> customers = new ArrayList<>();

	    public void addCustomer(Customer customer) {
	        customers.add(customer);
	    }

	    public Customer getCustomer(int id) {

	        for(Customer c : customers) {
				if(c.getUserId()==id) {
					return c;
				}
			}

	        return null;
	    }

	    public List<Customer> getCustomers() {
	        return customers;
	    }
}
