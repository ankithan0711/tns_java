package org.tnsif.fooddeliverysystem.services;


import java.util.ArrayList;
import java.util.List;

import org.tnsif.fooddeliverysystem.entities.DeliveryPerson;
import org.tnsif.fooddeliverysystem.entities.Order;

public class OrderService {
	private List<Order> orders = new ArrayList<>();
    private List<DeliveryPerson> deliveryPersons = new ArrayList<>();

    public void placeOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void addDeliveryPerson(DeliveryPerson dp) {
        deliveryPersons.add(dp);
    }

    public void assignDeliveryPerson(int orderId, int dpId) {

        Order order = null;
        DeliveryPerson dp = null;

        for(Order o: orders) {
			if(o.getOrderId()==orderId) {
				order = o;
			}
		}

        for(DeliveryPerson d : deliveryPersons) {
			if(d.getDeliveryPersonId()==dpId) {
				dp = d;
			}
		}

        if(order!=null && dp!=null) {
			order.setDeliveryPerson(dp);
		}
    }
}
