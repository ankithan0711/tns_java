package org.tnsif.fooddeliverysystem.services;

import java.util.ArrayList;
import java.util.List;

import org.tnsif.fooddeliverysystem.entities.FoodItem;
import org.tnsif.fooddeliverysystem.entities.Restaurant;

public class FoodService {
	private List<Restaurant> restaurants = new ArrayList<>();

    public void addRestaurant(Restaurant restaurant) {
        restaurants.add(restaurant);
    }

    public List<Restaurant> getRestaurants() {
        return restaurants;
    }

    public void addFoodItemToRestaurant(int restaurantId, FoodItem foodItem) {

        for(Restaurant r : restaurants) {
			if(r.getId()==restaurantId) {
				r.addFoodItem(foodItem);
			}
		}
    }
}
