package org.tnsif.fooddeliverysystem.entities;

import java.util.HashMap;
import java.util.Map;

public class Cart {

	private Map<FoodItem, Integer> items = new HashMap<>();

    public void addItem(FoodItem foodItem, int quantity) {

        if(items.containsKey(foodItem)) {
			items.put(foodItem, items.get(foodItem) + quantity);
		} else {
			items.put(foodItem, quantity);
		}
    }

    public void removeItem(FoodItem foodItem) {
        items.remove(foodItem);
    }

    public Map<FoodItem, Integer> getItems() {
        return items;
    }

    public double getTotalCost() {

        double total = 0;

        for(Map.Entry<FoodItem,Integer> entry : items.entrySet()) {
			total += entry.getKey().getPrice() * entry.getValue();
		}

        return total;
    }
}
