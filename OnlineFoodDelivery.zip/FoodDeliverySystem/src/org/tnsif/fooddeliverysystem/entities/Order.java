package org.tnsif.fooddeliverysystem.entities;

import java.util.Map;

public class Order {
	 private int orderId;
	    private Customer customer;
	    private Map<FoodItem,Integer> items;
	    private String status = "Pending";
	    private DeliveryPerson deliveryPerson;

	    public Order(int orderId, Customer customer, Map<FoodItem,Integer> items) {

	        this.orderId = orderId;
	        this.customer = customer;
	        this.items = items;
	    }

	    public int getOrderId() {
	        return orderId;
	    }

	    public void setDeliveryPerson(DeliveryPerson deliveryPerson) {
	        this.deliveryPerson = deliveryPerson;
	    }

	    @Override
	    public String toString() {
	        return "Order{id=" + orderId + ", customer=" + customer.getUsername() +
	                ", status=" + status +
	                ", deliveryPerson=" + (deliveryPerson==null?"Not Assigned":deliveryPerson.getName()) + "}";
	    }
}
