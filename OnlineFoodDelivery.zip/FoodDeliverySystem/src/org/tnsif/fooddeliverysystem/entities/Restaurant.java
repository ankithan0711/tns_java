package org.tnsif.fooddeliverysystem.entities;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
	 private int id;
	    private String name;
	    private List<FoodItem> menu = new ArrayList<>();

	    public Restaurant(int id, String name) {
	        this.id = id;
	        this.name = name;
	    }

	    public void addFoodItem(FoodItem foodItem) {
	        menu.add(foodItem);
	    }

	    public void removeFoodItem(int foodId) {
	        menu.removeIf(food -> food.getId() == foodId);
	    }

	    public List<FoodItem> getMenu() {
	        return menu;
	    }

	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }
}
